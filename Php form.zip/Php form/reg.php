<html>
<head>
<title> Program using PHP</title>
</head>
<body>
<?php
echo "<h1>welcome</h1>";
echo "<h2 style='color:blue'>welcome</h2>";
echo "<h1 style='color:yellow'>welcome</h1>";echo "<br>";
define("No","33");
echo No; echo "<br>";


$game="cricket";
echo "My favourite game is $game";echo "<br>";
$game=4;

echo gettype($game);echo "<br>";
echo settype($game,"string");echo "<br>";
echo gettype($game);echo "<br>";
echo is_string($game);


for($a=1;$a<=10;$a++){
	echo" program using for loop";echo "<br>";
}
echo "<br>";
$b=1;
while($b<10){
	
	echo" program using while loop";echo "<br>";
$b++;
}echo "<br>";


	$d=10;
	$opt=$d%2;
switch($opt){
	case 0:
	echo"No. is even"; break;
	case 1:
	echo "No. is odd";
}echo "<br>";
$player[0]="A";
$player[1]="B";
$player[2]="C";
$player[3]="D";
FOREACH($player as $players){
	echo $players. "<br>";
}
$name=$_POST['name1'];

echo "Welcome Mr. $name";
echo "<br>";

echo "Email of Mr. $name is ".$_POST['email1']; echo "<br>";
echo "Nationality of Mr. $name is ".$_POST['radio']; echo "<br>";
echo "City of Mr. $name is ".$_POST['name']; echo "<br>";
echo "checkBox of Mr. $name is ".$_POST['check']; echo "<br>";


?>
</body>
</html>