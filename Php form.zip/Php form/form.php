<html>
<head>
</head>
<body>
<form name="form1" method="post" action="reg.php">
<label>Enter Name</label>
<input type="text" name="name1" ><br><br>

<label>Enter Email</label>
<input type="text" name="email1" ><br><br>
<label>Religion:</label><br><br>
<input type="radio" name="radio" value="Muslim">Muslim &nbsp
&nbsp
&nbsp
<input type="radio" name="radio" value="Non-Muslim">Non-Muslim &nbsp

<br>

<label>City:</label>
&nbsp
&nbsp
&nbsp
<select name="name" >
<option value="Mailsi">Mailsi</option>
<option value="Lahore">Lahore</option>
<option value="Vehari">Vehari</option>
</select><br><br>
<input type="checkbox" name="check" value="CopyRights are reserved">CopyRights are reserved

<br>
<br>
<input type="submit" value="submit">
</form>
</body>
</html>